function arrosa(){
    document.body.style.backgroundColor = "pink"
    document.getElementById(taula).style.background = "white"
}
function berde(){
    document.body.style.backgroundColor = "ligthgreen"
    document.getElementById(taula).style.background = "white"
}
function gris(){
    document.body.style.backgroundColor = "lightblue"
    document.getElementById(taula).style.background = "white"
}
function grisa(){
    document.body.style.backgroundColor = "#444"
    document.getElementById(taula).style.background = "white"
}
function grisaa(){
    document.body.style.backgroundColor = "lightgrey"
    document.getElementById(taula).style.background = "white"
}
function gorria(){
    document.getElementById("Paragrafoa").style.color = "red";
}
function berdea(){
    document.getElementById("Paragrafoa").style.color = "green";
}
function urdina(){
    document.getElementById("Paragrafoa").style.color = "blue";
}
function beltza(){
    document.getElementById(Paragrafoa).style.background = "black"
}
function txuria(){
    document.getElementById(Paragrafoa).style.background = "white"
}
function xs(){
    document.getElementById(Paragrafoa).style.fontsize = "x-small"
}
function s(){
    document.getElementById(Paragrafoa).style.fontsize = "small"
}
function m(){
    document.getElementById(Paragrafoa).style.fontsize = "medium"
}
function l(){
    document.getElementById(Paragrafoa).style.fontsize = "large"
}
function xl(){
    document.getElementById(Paragrafoa).style.fontsize = "larger"
}
function a(){
    document.getElementById(Paragrafoa).style.fontFamily = "arial"
}
function t(){
    document.getElementById(Paragrafoa).style.fontFamily = "times"
}
function c(){
    document.getElementById(Paragrafoa).style.fontFamily = "courier"
}
function f(){
    document.getElementById(Paragrafoa).style.fontFamily = "fantasy"
}
function m(){
    document.getElementById(Paragrafoa).style.fontFamily = "monospace"
}